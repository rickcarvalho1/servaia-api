import { useState, useEffect } from "react";

const formatCurrency = (val) =>
  new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", maximumFractionDigits: 0 }).format(val);

export default function ServaiaCalculator() {
  const [avgJob, setAvgJob] = useState(350);
  const [jobsPerMonth, setJobsPerMonth] = useState(20);
  const [unpaidRate, setUnpaidRate] = useState(15);
  const [chaseHours, setChaseHours] = useState(5);
  const [hourlyValue, setHourlyValue] = useState(75);
  const [animated, setAnimated] = useState(false);

  useEffect(() => {
    setAnimated(false);
    const t = setTimeout(() => setAnimated(true), 50);
    return () => clearTimeout(t);
  }, [avgJob, jobsPerMonth, unpaidRate, chaseHours, hourlyValue]);

  const monthlyRevenue = avgJob * jobsPerMonth;
  const unpaidMonthly = monthlyRevenue * (unpaidRate / 100);
  const unpaidAnnual = unpaidMonthly * 12;
  const chaseTimeCost = chaseHours * hourlyValue * 12;
  const softwareSavings = (189 - 49) * 12; // vs Housecall Pro mid tier
  const totalAnnualLoss = unpaidAnnual + chaseTimeCost;
  const servaiaAnnual = 49 * 12;
  const roi = totalAnnualLoss / servaiaAnnual;

  const Slider = ({ label, value, setValue, min, max, step = 1, prefix = "", suffix = "", sublabel = "" }) => (
    <div style={{ marginBottom: "28px" }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: "10px" }}>
        <div>
          <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: "13px", fontWeight: 600, color: "#9ca3af", textTransform: "uppercase", letterSpacing: "0.08em" }}>{label}</div>
          {sublabel && <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: "11px", color: "#6b7280", marginTop: "2px" }}>{sublabel}</div>}
        </div>
        <div style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "28px", color: "#C9A84C", letterSpacing: "0.02em" }}>
          {prefix}{value.toLocaleString()}{suffix}
        </div>
      </div>
      <div style={{ position: "relative" }}>
        <input
          type="range"
          min={min}
          max={max}
          step={step}
          value={value}
          onChange={(e) => setValue(Number(e.target.value))}
          style={{
            width: "100%",
            height: "4px",
            appearance: "none",
            background: `linear-gradient(to right, #C9A84C ${((value - min) / (max - min)) * 100}%, #2a2a2a ${((value - min) / (max - min)) * 100}%)`,
            borderRadius: "2px",
            outline: "none",
            cursor: "pointer",
          }}
        />
      </div>
    </div>
  );

  const ResultCard = ({ label, value, highlight = false, delay = 0 }) => (
    <div style={{
      background: highlight ? "linear-gradient(135deg, #C9A84C15, #C9A84C08)" : "#141414",
      border: highlight ? "1px solid #C9A84C40" : "1px solid #222",
      borderRadius: "12px",
      padding: "20px 24px",
      transform: animated ? "translateY(0)" : "translateY(8px)",
      opacity: animated ? 1 : 0,
      transition: `all 0.4s ease ${delay}ms`,
    }}>
      <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: "12px", fontWeight: 600, color: "#6b7280", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: "8px" }}>{label}</div>
      <div style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: highlight ? "42px" : "34px", color: highlight ? "#C9A84C" : "#e5e7eb", letterSpacing: "0.02em", lineHeight: 1 }}>{value}</div>
    </div>
  );

  return (
    <div style={{
      minHeight: "100vh",
      background: "#0a0a0a",
      fontFamily: "'DM Sans', sans-serif",
      padding: "0",
      position: "relative",
      overflow: "hidden",
    }}>
      <link href="https://fonts.googleapis.com/css2?family=Bebas+Neue&family=DM+Sans:wght@300;400;500;600;700&display=swap" rel="stylesheet" />

      <style>{`
        input[type=range]::-webkit-slider-thumb {
          -webkit-appearance: none;
          width: 18px;
          height: 18px;
          border-radius: 50%;
          background: #C9A84C;
          cursor: pointer;
          box-shadow: 0 0 0 3px #0a0a0a, 0 0 0 5px #C9A84C40;
          transition: box-shadow 0.2s;
        }
        input[type=range]::-webkit-slider-thumb:hover {
          box-shadow: 0 0 0 3px #0a0a0a, 0 0 0 7px #C9A84C60;
        }
        input[type=range]::-moz-range-thumb {
          width: 18px;
          height: 18px;
          border-radius: 50%;
          background: #C9A84C;
          cursor: pointer;
          border: none;
        }
        .cta-btn:hover {
          background: #b8943e !important;
          transform: translateY(-2px) !important;
          box-shadow: 0 8px 30px #C9A84C40 !important;
        }
        .cta-btn {
          transition: all 0.2s ease !important;
        }
      `}</style>

      {/* Background grain */}
      <div style={{
        position: "fixed", inset: 0, opacity: 0.03, pointerEvents: "none", zIndex: 0,
        backgroundImage: "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)'/%3E%3C/svg%3E\")",
      }} />

      {/* Gold accent top bar */}
      <div style={{ height: "3px", background: "linear-gradient(90deg, transparent, #C9A84C, transparent)" }} />

      <div style={{ position: "relative", zIndex: 1, maxWidth: "960px", margin: "0 auto", padding: "48px 24px 80px" }}>

        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: "56px" }}>
          <div style={{ display: "inline-flex", alignItems: "center", gap: "10px", marginBottom: "24px" }}>
            <div style={{
              width: "36px", height: "36px", borderRadius: "50%",
              background: "#C9A84C", display: "flex", alignItems: "center", justifyContent: "center"
            }}>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none">
                <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z" fill="#0a0a0a" />
              </svg>
            </div>
            <span style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "22px", color: "#C9A84C", letterSpacing: "0.15em" }}>SERVAIA</span>
          </div>

          <h1 style={{
            fontFamily: "'Bebas Neue', sans-serif",
            fontSize: "clamp(36px, 7vw, 72px)",
            color: "#f9fafb",
            letterSpacing: "0.03em",
            lineHeight: 1.05,
            margin: "0 0 16px",
          }}>
            What Is Slow Payment<br />
            <span style={{ color: "#C9A84C" }}>Actually Costing You?</span>
          </h1>
          <p style={{ color: "#6b7280", fontSize: "17px", maxWidth: "480px", margin: "0 auto", lineHeight: 1.6, fontWeight: 400 }}>
            Move the sliders below. See what chasing invoices and unpaid jobs costs your business every year.
          </p>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "24px", alignItems: "start" }}>

          {/* Left — Sliders */}
          <div style={{
            background: "#111",
            border: "1px solid #1e1e1e",
            borderRadius: "20px",
            padding: "36px 32px",
          }}>
            <div style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "18px", color: "#C9A84C", letterSpacing: "0.12em", marginBottom: "28px" }}>YOUR BUSINESS</div>

            <Slider label="Average Job Value" value={avgJob} setValue={setAvgJob} min={100} max={2000} step={25} prefix="$" />
            <Slider label="Jobs Per Month" value={jobsPerMonth} setValue={setJobsPerMonth} min={5} max={100} suffix=" jobs" />
            <Slider label="Unpaid / Late Invoice Rate" value={unpaidRate} setValue={setUnpaidRate} min={1} max={50} suffix="%" sublabel="Industry avg: 15–25%" />
            <Slider label="Hours Chasing Payments / Month" value={chaseHours} setValue={setChaseHours} min={1} max={20} suffix=" hrs" />
            <Slider label="Your Time Is Worth" value={hourlyValue} setValue={setHourlyValue} min={25} max={200} step={5} prefix="$" suffix="/hr" />
          </div>

          {/* Right — Results */}
          <div style={{ display: "flex", flexDirection: "column", gap: "16px" }}>

            <div style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "18px", color: "#C9A84C", letterSpacing: "0.12em", marginBottom: "4px" }}>THE REAL NUMBERS</div>

            <ResultCard label="Monthly Revenue at Stake" value={formatCurrency(monthlyRevenue)} delay={0} />
            <ResultCard label="Lost to Unpaid Invoices (Annual)" value={formatCurrency(unpaidAnnual)} delay={60} />
            <ResultCard label="Time Wasted Chasing (Annual)" value={formatCurrency(chaseTimeCost)} delay={120} />

            <div style={{
              height: "1px",
              background: "linear-gradient(90deg, transparent, #C9A84C40, transparent)",
              margin: "4px 0"
            }} />

            <ResultCard label="Total Annual Cost of Slow Payments" value={formatCurrency(totalAnnualLoss)} highlight delay={180} />

            {/* Comparison bar */}
            <div style={{
              background: "#111",
              border: "1px solid #1e1e1e",
              borderRadius: "12px",
              padding: "20px 24px",
              transform: animated ? "translateY(0)" : "translateY(8px)",
              opacity: animated ? 1 : 0,
              transition: "all 0.4s ease 240ms",
            }}>
              <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: "12px", fontWeight: 600, color: "#6b7280", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: "14px" }}>Servaia vs. The Problem</div>

              <div style={{ marginBottom: "12px" }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "5px" }}>
                  <span style={{ fontSize: "13px", color: "#9ca3af" }}>What you're losing annually</span>
                  <span style={{ fontSize: "13px", color: "#ef4444", fontWeight: 600 }}>{formatCurrency(totalAnnualLoss)}</span>
                </div>
                <div style={{ height: "6px", background: "#1e1e1e", borderRadius: "3px" }}>
                  <div style={{ height: "100%", width: "100%", background: "#ef444440", borderRadius: "3px" }} />
                </div>
              </div>

              <div>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: "5px" }}>
                  <span style={{ fontSize: "13px", color: "#9ca3af" }}>Servaia costs you annually</span>
                  <span style={{ fontSize: "13px", color: "#C9A84C", fontWeight: 600 }}>{formatCurrency(servaiaAnnual)}</span>
                </div>
                <div style={{ height: "6px", background: "#1e1e1e", borderRadius: "3px" }}>
                  <div style={{
                    height: "100%",
                    width: `${Math.min((servaiaAnnual / totalAnnualLoss) * 100, 100)}%`,
                    background: "#C9A84C",
                    borderRadius: "3px",
                    transition: "width 0.5s ease"
                  }} />
                </div>
              </div>

              <div style={{
                marginTop: "16px",
                padding: "12px 16px",
                background: "#C9A84C10",
                borderRadius: "8px",
                border: "1px solid #C9A84C20",
                textAlign: "center"
              }}>
                <span style={{ fontFamily: "'DM Sans', sans-serif", fontSize: "13px", color: "#9ca3af" }}>
                  For every $1 spent on Servaia, you recover{" "}
                </span>
                <span style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "22px", color: "#C9A84C" }}>
                  ${roi.toFixed(0)}
                </span>
              </div>
            </div>

            {/* vs competitors */}
            <div style={{
              background: "#111",
              border: "1px solid #1e1e1e",
              borderRadius: "12px",
              padding: "16px 24px",
              transform: animated ? "translateY(0)" : "translateY(8px)",
              opacity: animated ? 1 : 0,
              transition: "all 0.4s ease 300ms",
            }}>
              <div style={{ fontFamily: "'DM Sans', sans-serif", fontSize: "12px", fontWeight: 600, color: "#6b7280", textTransform: "uppercase", letterSpacing: "0.1em", marginBottom: "12px" }}>vs. Scheduling Software Alone</div>
              <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
                {[
                  { name: "Housecall Pro (Basic)", price: "$79/mo", note: "scheduling only" },
                  { name: "Housecall Pro (Essential)", price: "$189/mo", note: "scheduling only" },
                  { name: "Jobber (Core)", price: "$69/mo", note: "no payment recovery" },
                  { name: "Servaia", price: "$49/mo", note: "gets you paid same day", gold: true },
                ].map((item) => (
                  <div key={item.name} style={{
                    display: "flex", justifyContent: "space-between", alignItems: "center",
                    padding: "8px 12px",
                    background: item.gold ? "#C9A84C12" : "transparent",
                    borderRadius: "8px",
                    border: item.gold ? "1px solid #C9A84C30" : "1px solid transparent",
                  }}>
                    <div>
                      <span style={{ fontSize: "13px", color: item.gold ? "#f9fafb" : "#6b7280", fontWeight: item.gold ? 600 : 400 }}>{item.name}</span>
                      <span style={{ fontSize: "11px", color: "#4b5563", marginLeft: "8px" }}>{item.note}</span>
                    </div>
                    <span style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "18px", color: item.gold ? "#C9A84C" : "#4b5563" }}>{item.price}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* CTA */}
            <button
              className="cta-btn"
              onClick={() => window.open("https://app.servaiapay.com/signup", "_blank")}
              style={{
                width: "100%",
                padding: "18px",
                background: "#C9A84C",
                color: "#0a0a0a",
                border: "none",
                borderRadius: "12px",
                fontFamily: "'Bebas Neue', sans-serif",
                fontSize: "20px",
                letterSpacing: "0.1em",
                cursor: "pointer",
                marginTop: "4px",
              }}
            >
              START FREE — 30 DAYS, NO CARD NEEDED
            </button>
            <p style={{ textAlign: "center", fontSize: "12px", color: "#4b5563", margin: "-4px 0 0" }}>
              Cancel anytime. No contracts. Lock in $49/mo forever.
            </p>
          </div>
        </div>

        {/* Bottom tagline */}
        <div style={{ textAlign: "center", marginTop: "64px" }}>
          <p style={{ fontFamily: "'Bebas Neue', sans-serif", fontSize: "clamp(20px, 4vw, 32px)", color: "#2a2a2a", letterSpacing: "0.05em" }}>
            GET PAID THE MOMENT THE JOB IS DONE.
          </p>
        </div>
      </div>
    </div>
  );
}
